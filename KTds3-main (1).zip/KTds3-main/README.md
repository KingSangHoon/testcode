# KTds3

# KTds Microsoft AI 3기 과정

## Daily 교육자료.

[<Day 4> Azure OpenAI 사용법 외 Streamlit 웹 개발](./Day%204/README.md)

[<Day 5> Azure Web App, Storage, NLP ](./Day%205/README.md)

## 참고 자료 
[Git 강좌](https://www.youtube.com/watch?v=JZJQ4_8XoPM&list=PLHF1wYTaCuixewA1hAn8u6hzx5mNenAGM)

[Markdown](https://inpa.tistory.com/entry/MarkDown-%F0%9F%93%9A-%EB%A7%88%ED%81%AC%EB%8B%A4%EC%9A%B4-%EB%AC%B8%EB%B2%95-%F0%9F%92%AF-%EC%A0%95%EB%A6%AC)